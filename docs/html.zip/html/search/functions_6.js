var searchData=
[
  ['setname_37',['setName',['../classwebserver.html#a61c7e3cd7f4682601aae517acce300ca',1,'webserver']]]
];
