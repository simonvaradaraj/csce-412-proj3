var searchData=
[
  ['webserver_17',['webserver',['../classwebserver.html',1,'webserver'],['../classwebserver.html#ae6f13a3cb80fe961cdaf70c7e03f36dc',1,'webserver::webserver()'],['../classwebserver.html#a4d62d90c52a9feff92154fc41c5012ba',1,'webserver::webserver(string name)']]],
  ['webserver_2eh_18',['webserver.h',['../webserver_8h.html',1,'']]]
];
