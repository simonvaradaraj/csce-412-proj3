var searchData=
[
  ['jobtype_40',['jobType',['../classrequest.html#a01ba40d977db5174b78062ede1a57486',1,'request']]]
];
