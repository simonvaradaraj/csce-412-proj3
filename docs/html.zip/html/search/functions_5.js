var searchData=
[
  ['request_36',['request',['../classrequest.html#ae49e0b00a54017889a18e955b88087f6',1,'request::request()'],['../classrequest.html#ae04b50005e1fbe777cc40abea4ffa199',1,'request::request(string ipIn, string ipOut, int time, char jobType)']]]
];
